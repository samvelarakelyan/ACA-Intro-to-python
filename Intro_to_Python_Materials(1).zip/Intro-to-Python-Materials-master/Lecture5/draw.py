def draw_game(res):
    print("draw game",res)

def clear_screen(screen):
    pass