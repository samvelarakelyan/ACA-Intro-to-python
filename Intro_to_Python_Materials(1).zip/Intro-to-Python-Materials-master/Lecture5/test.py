def times(x,y):
    z = x*y
    return z

times(2,3)