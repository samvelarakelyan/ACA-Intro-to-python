import sys


print('Script name:', sys.argv[0])
print('Arguments:', sys.argv[1:])
print('# of arguments:', len(sys.argv[1:]))

#naming arguments to use in code
a = sys.argv[1]
print('First argument:', a)