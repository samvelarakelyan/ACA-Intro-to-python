from Rect import Rectangle


def main():
    rec1 = Rectangle(10,5)
    print("The area of the rectange is: ", rec1.area())


if __name__ == '__main__':
    main()